// 1 – Criando Variáveis
// let num1 = 5;
// let num2 = 5;
// console.log(num1 + num2);

// let nome = "Hellen Fernandes";
// console.log(`Olá ${nome}!`);

// let prof = "Estudante"
// console.log(true)
// console.log

// let num = 3.2415
// console.log(${num});

// 2 - Utilizando os conceitos apresentados, pergunte ao usuário
// let nomeUsuario = (prompt(`Qual o seu nome?`));
// prompt(`Qual a sua idade?`);
// prompt(`Qual o bairro onde mora?`);
// alert(`Olá ${nomeUsuario}`);
// let numero1 =Number (prompt`Digite um número:`);
// let numero2 = Number (prompt`Digite outro número:`);
// alert(`O resultado é: ${numero1 + numero2}`);

// 4 Crie um variável preço e atribua a ela um valor numérico
// let preço = (prompt('Qual o valor?'));
// let desconto = (prompt('Desconto:'));
// alert(`O preço do produto é: ${preço %- desconto}`)


// Exercício 5:
// let idade = Number(prompt(`Qual sua idade?`));

// if (idade < 18){
//     alert("Usuário menor de idade.")
// }
// else if(idade >= 18 && idade <= 60){
//     alert("Usuário adulto.")
// }
// else if(idade >= 60){
//     alert("Usuário idoso.")
// }
// console.log('Final do programa');

// Exercício 6
// let idade = Number(prompt('Qual sua idade?'));
// if (idade >=18){
//     alert('Você pode dirigir!')
// }
// else if (idade <18){
//     alert('Você ainda não pode dirigir!')
// }

// Exercício 7

// let num = Number(prompt('Digite um número:'));
// if (num >=0) {
//     alert('Número positivo')
// }
// else if (num <0 ) {
//     alert('Número negativo')
// }
// else if (num =0) {
//     alert('Número zero')
// }

// Exercício 8:
// let altura = Number(prompt('Digite sua altura'));
// let peso = Number(prompt('Digite seu peso'));
// let resultado = (peso * altura /2);
// console.log(`Seu IMC é de: ${resultado}`);
// alert(`Seu IMC é de: ${resultado}`);
// if (resultado < 18,5){
//     alert('Não saudável')
// }
// else if(resultado >=18,25 && resultado<24,9){
//     alert('Saudádel')
// }